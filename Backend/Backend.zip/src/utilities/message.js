export default {
    usersFetched: 'ok',
    serverError: 'Internal Server Error',
    validationErrors: 'Validation Errors'
}
