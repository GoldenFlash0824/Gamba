module.exports = {
    bracketSpacing: false,
    jsxBracketSameLine: true,
    singleQuote: true,
    trailingComma: 'none',
    arrowParens: 'always',
    tab: true,
    tabWidth: 4,
    lineLength: 80,
    semi: false,
    space: 4,
    printWidth: 1050
}
