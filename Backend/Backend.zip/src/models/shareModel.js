const sharePostModel = (sequelize, DataTypes) => {
    const model = sequelize.define('shareModel', {})
    return model
}
export default sharePostModel
